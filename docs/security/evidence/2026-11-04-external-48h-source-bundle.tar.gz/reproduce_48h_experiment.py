"""Reproducible 48-hour experiment (task-279 and task-286) anchored at 2026-11-03T11:59:59.999000+00:00.

Usage:
  1. Freeze raw inputs up to 2026-11-03T12:00:00Z from Binance public endpoints (or use existing raw_inputs_20261103T1200Z.json):
     .venv/bin/python reproduce_48h_experiment.py --fetch-and-freeze
  2. Run deterministic offline reproduction from the frozen JSON file (zero network calls):
     .venv/bin/python reproduce_48h_experiment.py
"""
from __future__ import annotations

import argparse
import asyncio
import json
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

from algotrader.application.alt_momentum import _return_over
from algotrader.config import load_settings
from algotrader.domain.archetypes import LongArchetypeFeatures, classify_long_archetype
from algotrader.domain.crypto_screener_models import SetupLabel
from algotrader.domain.indicators import (
    bollinger_bands,
    cumulative_volume_delta_metrics,
    ema,
    keltner_channels,
    macd,
    resample_candles,
    rsi,
    snapshot,
    taker_buy_ratio_from_candles,
    volume_contraction_metrics,
    volume_profile,
)
from algotrader.domain.models import Candle
from algotrader.domain.screening_gates import LongGateInputs, evaluate_long_gates
from algotrader.infrastructure.runtime import build_runtime

SCRATCH_DIR = Path(__file__).resolve().parent
RAW_INPUTS_PATH = SCRATCH_DIR / "raw_inputs_20261103T1200Z.json"
RESULTS_PATH = SCRATCH_DIR / "experiment_results_20261103T1200Z.json"

# Exact UTC end time of the T-0h closed 1H candle in task-279 (started 2026-11-03T12:01:08Z)
# and task-286 (started 2026-11-03T12:04:21Z):
# Candle opened_at = 2026-11-03T11:00:00+00:00, closed_at = 2026-11-03T11:59:59.999000+00:00
ANCHOR_END_UTC = datetime(2026, 11, 3, 11, 59, 59, 999000, tzinfo=UTC)
ANCHOR_END_MS = int(ANCHOR_END_UTC.timestamp() * 1000)

# Exact live quote snapshots captured in task-279 (2026-11-03T12:01:10Z) & task-286 (2026-11-03T12:04:23Z)
TASK_279_QUOTES: dict[str, dict[str, str]] = {
    "HOTUSDT": {
        "last_279": "0.0005363",
        "last_286": "0.00053315",
        "price_change_pct_24h": "41.863",
        "funding_rate": "-0.00004900",
        "basis_pct": "-0.000908",
    },
    "ICNTUSDT": {
        "last_279": "0.2277000",
        "last_286": "0.2274500",
        "price_change_pct_24h": "36.747",
        "funding_rate": "-0.00034000",
        "basis_pct": "-0.000400",
    },
    "BMTUSDT": {
        "last_279": "0.0228550",
        "last_286": "0.0229800",
        "price_change_pct_24h": "8.961",
        "funding_rate": "-0.00994300",
        "basis_pct": "-0.016792",
    },
    "MEGAUSDT": {
        "last_279": "0.0439250",
        "last_286": "0.0439650",
        "price_change_pct_24h": "-0.947",
        "funding_rate": "0.00005000",
        "basis_pct": "0.000120",
    },
    "TRUSTUSDT": {
        "last_279": "0.0539100",
        "last_286": "0.0539100",
        "price_change_pct_24h": "5.650",
        "funding_rate": "0.00015000",
        "basis_pct": "0.001910",
    },
    "BEATUSDT": {
        "last_279": "0.1015000",
        "last_286": "0.1015000",
        "price_change_pct_24h": "3.100",
        "funding_rate": "0.00020400",
        "basis_pct": "0.001627",
    },
}

SYMBOLS = ("HOTUSDT", "ICNTUSDT", "BMTUSDT", "MEGAUSDT", "TRUSTUSDT", "BEATUSDT")


def eval_patched_archetype_and_gates(
    lf: LongArchetypeFeatures, gi: LongGateInputs
) -> tuple[SetupLabel | None, bool, dict[str, bool]]:
    arch = classify_long_archetype(lf)
    if arch is None:
        if (
            lf.funding_rate_8h is not None
            and lf.funding_rate_8h <= Decimal("-0.0005")
            and lf.oi_delta_24h is not None
            and lf.oi_delta_24h >= Decimal("0.15")
            and lf.bb_bandwidth_4h <= Decimal("0.18")
            and lf.close >= lf.ema20_4h * Decimal("0.985")
            and lf.low_4h > lf.low_30d * Decimal("1.03")
        ):
            arch = SetupLabel.SHORT_SQUEEZE_ABSORPTION_LONG

    _, g_det_raw = evaluate_long_gates(gi, arch)
    g_det = dict(g_det_raw)
    arch_str = arch.value if arch is not None else ""

    if not g_det["L6"] and arch_str in ("OI_ACCUMULATION_LONG", "SHORT_SQUEEZE_ABSORPTION_LONG"):
        if (
            gi.oi_delta_7d is not None
            and gi.oi_delta_7d >= Decimal("0.25")
            and gi.oi_delta_24h is not None
            and gi.oi_delta_24h >= Decimal("0.15")
            and (gi.oi_delta_4h is None or gi.oi_delta_4h >= Decimal("0.0"))
            and (gi.oi_delta_1h is None or gi.oi_delta_1h >= Decimal("-0.02"))
            and gi.close >= gi.ema50_4h
            and gi.close >= gi.poc_30d * Decimal("0.98")
        ):
            g_det["L6"] = True

    if not g_det["L3"] and arch_str in (
        "RANGE_BOTTOM_ACCUMULATION_LONG",
        "COIL_SPRING_LONG",
        "OI_ACCUMULATION_LONG",
        "SHORT_SQUEEZE_ABSORPTION_LONG",
    ):
        range_height_30d = (gi.high_30d - gi.low_30d) / max(gi.low_30d, Decimal("1e-8"))
        dist_to_ceiling = (gi.high_30d - gi.close) / max(gi.close, Decimal("1e-8"))
        if range_height_30d <= Decimal("2.50") and Decimal("-0.05") <= dist_to_ceiling <= Decimal("0.85"):
            g_det["L3"] = True

    if not g_det["L1"] and arch_str == "SHORT_SQUEEZE_ABSORPTION_LONG":
        if (
            gi.funding_rate_8h is not None
            and gi.funding_rate_8h <= Decimal("-0.0005")
            and gi.oi_delta_24h is not None
            and gi.oi_delta_24h >= Decimal("0.15")
            and gi.bb_bandwidth_4h <= Decimal("0.18")
            and gi.close >= gi.ema20_4h * Decimal("0.985")
        ):
            g_det["L1"] = True

    return arch, all(g_det.values()), g_det


def institutional_continuous_eval(
    close: Decimal,
    low_30d: Decimal,
    high_30d: Decimal,
    ema20_4h: Decimal,
    ema50_4h: Decimal,
    ema200_4h: Decimal,
    val_30d: Decimal,
    poc_30d: Decimal,
    vah_30d: Decimal,
    bbw_4h: Decimal,
    bb_in_kc: bool,
    vcr: Decimal,
    ret_24h: Decimal,
    exc_72h: Decimal,
    rsi_1h: Decimal,
    rsi_4h: Decimal,
    rsi_1d: Decimal | None,
    oi_7d: Decimal | None,
    oi_24h: Decimal | None,
    oi_4h: Decimal | None,
    oi_1h: Decimal | None,
    funding_bps: float,
    basis_bps: float,
    taker_4h: Decimal | None,
    taker_1h: Decimal | None,
    wicks_4h_avg: float,
) -> tuple[bool, float, str]:
    if (
        float(ret_24h) > 0.16
        or float(rsi_4h) > 71.0
        or (rsi_1d is not None and float(rsi_1d) >= 70.0)
        or float(rsi_1h) > 76.0
    ):
        return False, 0.0, "HYGIENE_OVEREXTENDED"
    if (oi_1h is not None and float(oi_1h) < -0.025) or (oi_24h is not None and float(oi_24h) < -0.08):
        return False, 0.0, "HYGIENE_OI_DRAIN"
    support_floor = min(float(ema20_4h), float(ema50_4h), float(val_30d))
    if float(close) < float(low_30d) * 1.03 or float(close) < support_floor * 0.96:
        return False, 0.0, "HYGIENE_BROKEN_FLOOR"

    oi7 = float(oi_7d or 0)
    oi24 = float(oi_24h or 0)
    oi4 = float(oi_4h or 0)
    oi1 = float(oi_1h or 0)
    pts_oi = 0.0
    if oi24 > 0 and oi4 >= -0.005:
        pts_oi += min(12.0, max(0.0, oi7 * 20.0))
        pts_oi += min(12.0, max(0.0, oi24 * 30.0))
        pts_oi += min(6.0, max(0.0, oi4 * 60.0 + oi1 * 80.0))

    pts_squeeze = 0.0
    if funding_bps <= -0.5:
        pts_squeeze += min(12.0, 4.0 + abs(funding_bps) * 1.5)
    elif funding_bps <= 1.0:
        pts_squeeze += 4.0
    if basis_bps < 0:
        pts_squeeze += min(8.0, abs(basis_bps) * 0.8)
    elif basis_bps > 15.0:
        pts_squeeze -= min(8.0, (basis_bps - 15.0) * 0.5)

    pts_coil = 0.0
    bbw_f = float(bbw_4h)
    vcr_f = float(vcr)
    if bbw_f <= 0.25:
        pts_coil += 12.0 * (0.25 - bbw_f) / 0.18
    if bb_in_kc:
        pts_coil += 4.0
    if vcr_f <= 1.00:
        pts_coil += min(6.0, (1.10 - vcr_f) * 10.0)
    pts_coil = min(20.0, max(0.0, pts_coil))

    pts_struct = 0.0
    if float(close) >= float(ema20_4h) * 0.99:
        pts_struct += 6.0
    if float(close) >= float(ema50_4h) * 0.99:
        pts_struct += 7.0
    if float(close) >= float(poc_30d) * 0.985:
        pts_struct += 7.0
    elif float(close) >= float(val_30d) * 0.99:
        pts_struct += 4.0

    t4 = float(taker_4h or 1.0)
    t1 = float(taker_1h or 1.0)
    pts_flow = min(10.0, max(-5.0, (max(t4, t1) - 0.96) * 50.0))
    if -0.02 <= float(ret_24h) <= 0.12:
        pts_flow += 5.0
    if wicks_4h_avg > 0.45:
        pts_flow -= (wicks_4h_avg - 0.40) * 25.0

    total_score = round(pts_oi + pts_squeeze + pts_coil + pts_struct + pts_flow, 1)
    vecs = {
        "OI_ACCUMULATION_LONG": pts_oi,
        "SHORT_SQUEEZE_ABSORPTION_LONG": pts_squeeze,
        "COIL_SPRING_LONG": pts_coil,
        "RANGE_BOTTOM_ACCUMULATION_LONG": pts_struct,
    }
    best_arch = max(vecs, key=lambda k: vecs[k])
    passed = total_score >= 52.0 and (
        pts_oi >= 8.0 or pts_squeeze >= 10.0 or (pts_coil >= 12.0 and pts_oi >= 4.0)
    )
    return passed, total_score, best_arch


def _serialize_candle(c: Candle) -> dict[str, Any]:
    return {
        "opened_at": c.opened_at.isoformat(),
        "closed_at": c.closed_at.isoformat(),
        "open": str(c.open),
        "high": str(c.high),
        "low": str(c.low),
        "close": str(c.close),
        "volume": str(c.volume),
        "quote_volume": str(c.quote_volume),
        "closed": c.closed,
        "taker_buy_volume": str(c.taker_buy_volume),
        "taker_buy_quote_volume": str(c.taker_buy_quote_volume),
    }


def _deserialize_candle(d: dict[str, Any]) -> Candle:
    return Candle(
        opened_at=datetime.fromisoformat(d["opened_at"]),
        closed_at=datetime.fromisoformat(d["closed_at"]),
        open=Decimal(d["open"]),
        high=Decimal(d["high"]),
        low=Decimal(d["low"]),
        close=Decimal(d["close"]),
        volume=Decimal(d["volume"]),
        quote_volume=Decimal(d["quote_volume"]),
        closed=bool(d["closed"]),
        taker_buy_volume=Decimal(d["taker_buy_volume"]),
        taker_buy_quote_volume=Decimal(d["taker_buy_quote_volume"]),
    )


async def fetch_and_freeze() -> None:
    rt = await build_runtime(load_settings())
    try:
        insts = await rt.futures_market.instruments()
        by_sym = {i.id.symbol: i for i in insts if i.id.symbol in SYMBOLS}
        payload: dict[str, Any] = {
            "experiment_metadata": {
                "anchor_end_utc": ANCHOR_END_UTC.isoformat(),
                "anchor_end_ms": ANCHOR_END_MS,
                "task_279_started_utc": "2026-11-03T12:01:08+00:00",
                "task_279_completed_utc": "2026-11-03T12:01:22+00:00",
                "task_286_started_utc": "2026-11-03T12:04:21+00:00",
                "task_286_completed_utc": "2026-11-03T12:04:36+00:00",
                "t0_1h_candle_open_utc": "2026-11-03T11:00:00+00:00",
                "t0_1h_candle_close_utc": "2026-11-03T11:59:59.999000+00:00",
            },
            "quotes_at_anchor": TASK_279_QUOTES,
            "symbols": {},
        }
        for sym in SYMBOLS:
            inst = by_sym[sym]
            # Page historical klines and openInterestHist bounded by ANCHOR_END_MS
            c1h_raw = await rt.futures_market._client.request(
                "GET",
                "/fapi/v1/klines",
                params={"symbol": sym, "interval": "1h", "endTime": ANCHOR_END_MS, "limit": 320},
            )
            c4h_raw = await rt.futures_market._client.request(
                "GET",
                "/fapi/v1/klines",
                params={"symbol": sym, "interval": "4h", "endTime": ANCHOR_END_MS, "limit": 240},
            )
            c1w_raw = await rt.futures_market._client.request(
                "GET",
                "/fapi/v1/klines",
                params={"symbol": sym, "interval": "1w", "endTime": ANCHOR_END_MS, "limit": 40},
            )
            oi_raw = await rt.futures_market._client.request(
                "GET",
                "/futures/data/openInterestHist",
                params={"symbol": sym, "period": "1h", "endTime": ANCHOR_END_MS + 60000, "limit": 200},
            )
            c1h = [
                _serialize_candle(c)
                for c in rt.futures_market._parse_candle_rows(c1h_raw)
                if c.closed_at <= ANCHOR_END_UTC
            ][-319:]
            c4h = [
                _serialize_candle(c)
                for c in rt.futures_market._parse_candle_rows(c4h_raw)
                if c.closed_at <= ANCHOR_END_UTC
            ][-239:]
            c1w = [
                _serialize_candle(c)
                for c in rt.futures_market._parse_candle_rows(c1w_raw)
                if c.closed_at <= ANCHOR_END_UTC
            ][-39:]
            payload["symbols"][sym] = {
                "candles_1h": c1h,
                "candles_4h": c4h,
                "candles_1w": c1w,
                "open_interest_hist_1h": oi_raw,
            }
        RAW_INPUTS_PATH.write_text(json.dumps(payload, indent=2))
        print(f"Saved frozen raw inputs to {RAW_INPUTS_PATH}")
    finally:
        await rt.close()


def run_offline_reproduction() -> dict[str, Any]:
    raw = json.loads(RAW_INPUTS_PATH.read_text())
    results: dict[str, Any] = {
        "anchor_end_utc": raw["experiment_metadata"]["anchor_end_utc"],
        "task_279_reproduction": {},
        "task_286_reproduction": {},
    }

    print("=== REPRODUCING TASK-279 (Horizons: 44, 40, 36, 32, 28, 24, 20, 16, 12, 8, 4, 0) ===")
    for sym in ("HOTUSDT", "ICNTUSDT", "BMTUSDT", "MEGAUSDT"):
        sym_data = raw["symbols"][sym]
        q_info = raw["quotes_at_anchor"][sym]
        last_279 = Decimal(q_info["last_279"])
        funding_rate = Decimal(q_info["funding_rate"])
        c1h_all = [_deserialize_candle(d) for d in sym_data["candles_1h"]]
        c4h_all = [_deserialize_candle(d) for d in sym_data["candles_4h"]]
        c1w_all = [_deserialize_candle(d) for d in sym_data["candles_1w"]]
        oi_hist = sym_data["open_interest_hist_1h"]

        horizons_279 = [44, 40, 36, 32, 28, 24, 20, 16, 12, 8, 4, 0]
        rows_279 = []
        base_hits = 0
        patch_hits = 0
        print(f"\n==================== {sym} (Now={last_279}, 24hChg={q_info['price_change_pct_24h']}%) ====================")
        for h in horizons_279:
            c1h = c1h_all[:-h] if h > 0 else c1h_all
            last_ts = c1h[-1].closed_at
            c4h = [c for c in c4h_all if c.closed_at <= last_ts]
            snap_1h = snapshot(c1h)
            close = snap_1h.close
            fwd_ret = float((last_279 - close) / close * 100)
            closes_4h = [c.close for c in c4h]
            ema20_4h = ema(closes_4h, 20)[-1]
            ema50_4h = ema(closes_4h, 50)[-1]
            ema200_4h = ema(closes_4h, min(200, len(closes_4h)))[-1]
            rsi_4h = rsi(closes_4h, 14)[-1]
            ret_24h = _return_over(c1h, 24)
            ret_7d = _return_over(c1h, 168) if len(c1h) >= 169 else Decimal("0")
            last_72h = c1h[-72:]
            exc_72h = (max(c.high for c in last_72h) - min(c.low for c in last_72h)) / min(c.low for c in last_72h)
            base_win = c4h[-120:] if len(c4h) >= 120 else c4h
            high_30d = max(c.high for c in base_win)
            low_30d = min(c.low for c in base_win)
            pos_in_range = (close - low_30d) / (high_30d - low_30d)
            vp = volume_profile(c4h[-180:] if len(c4h) >= 180 else c4h, bins=40)
            bb_u, bb_m, bb_l, bbw_4h = bollinger_bands(closes_4h, 20, Decimal("2.0"))
            kc_u, kc_m, kc_l = keltner_channels(c4h, 20, Decimal("1.5"))
            bb_in_kc_series = [
                bool(bl is not None and kl is not None and bh is not None and kh is not None and bl >= kl and bh <= kh)
                for bl, kl, bh, kh in zip(bb_l, kc_l, bb_u, kc_u)
            ]
            _, _, vcr = volume_contraction_metrics(c1h, 7, 14)
            taker_calc_4h = taker_buy_ratio_from_candles(c1h, hours=4)
            cvd_m = cumulative_volume_delta_metrics(c1h, lookback_window=24)
            _, _, macd_h = macd(closes_4h)

            ts_ms = int(last_ts.timestamp() * 1000)
            oi_valid = [r for r in oi_hist if int(r["timestamp"]) <= ts_ms + 60000]
            oi_7d = oi_24h = oi_4h = oi_1h = None
            if len(oi_valid) >= 25:
                cur_oi = Decimal(str(oi_valid[-1]["sumOpenInterest"]))
                oi_1h = (cur_oi - Decimal(str(oi_valid[-2]["sumOpenInterest"]))) / Decimal(str(oi_valid[-2]["sumOpenInterest"]))
                oi_4h = (cur_oi - Decimal(str(oi_valid[-5]["sumOpenInterest"]))) / Decimal(str(oi_valid[-5]["sumOpenInterest"]))
                oi_24h = (cur_oi - Decimal(str(oi_valid[-25]["sumOpenInterest"]))) / Decimal(str(oi_valid[-25]["sumOpenInterest"]))
                idx_7d = max(0, len(oi_valid) - 169)
                oi_7d = (cur_oi - Decimal(str(oi_valid[idx_7d]["sumOpenInterest"]))) / Decimal(str(oi_valid[idx_7d]["sumOpenInterest"]))

            lf = LongArchetypeFeatures(
                close=close,
                low_24h=min(c.low for c in c1h[-24:]),
                ema50_4h=ema50_4h,
                poc_30d=vp.poc_price,
                vah_30d=vp.vah_price,
                atr14_4h=snap_1h.atr14,
                vcr_4h=vcr,
                oi_delta_7d=oi_7d,
                oi_delta_4h=oi_4h,
                ret_7d=ret_7d,
                bb_inside_kc_4h=bb_in_kc_series[-1] if bb_in_kc_series else False,
                bb_bandwidth_4h=bbw_4h[-1] if bbw_4h else Decimal("0.2"),
                local_swing_high_4h=max(c.high for c in c4h[-18:]),
                rvol_4h=snap_1h.relative_volume,
                norm_momentum_1h=snap_1h.momentum_normalized,
                btc_residual_alpha_24h=ret_24h,
                macd_hist_4h=macd_h[-1],
                macd_hist_4h_prev=macd_h[-2],
                macd_hist_1h=snap_1h.macd_hist,
                taker_buy_ratio_4h=taker_calc_4h,
                range_height_30d=(high_30d - low_30d) / low_30d,
                pos_in_range_30d=pos_in_range,
                dist_to_ceiling=(high_30d - close) / close,
                val_30d=vp.val_price,
                funding_rate_8h=funding_rate,
                cvd_24h=cvd_m.cvd_24h_change,
                ret_24h=ret_24h,
                oi_delta_24h=oi_24h,
                taker_buy_ratio_1h=taker_buy_ratio_from_candles(c1h, hours=1),
                low_30d=low_30d,
                low_4h=c4h[-1].low,
                ema20_4h=ema20_4h,
                ema20_1h=snap_1h.ema20,
                rvol_1h=snap_1h.relative_volume,
            )
            c1d = resample_candles(c4h, "1d")
            rsi_1d = rsi([c.close for c in c1d], 14)[-1] if len(c1d) >= 15 else None
            rsi_1w = rsi([c.close for c in c1w_all], 14)[-1] if len(c1w_all) >= 15 else None
            gi = LongGateInputs(
                close=close,
                ema50_4h=ema50_4h,
                ema20_1h=snap_1h.ema20,
                ema200_4h=ema200_4h,
                low_24h=min(c.low for c in c1h[-24:]),
                atr14_4h=snap_1h.atr14,
                vcr_4h=vcr,
                ema20_4h=ema20_4h,
                excursion_72h=exc_72h,
                ret_24h=ret_24h,
                rsi_1h=snap_1h.rsi14,
                rsi_4h=rsi_4h,
                rsi_1d=rsi_1d,
                rsi_1w=rsi_1w,
                high_30d=high_30d,
                low_30d=low_30d,
                poc_30d=vp.poc_price,
                val_30d=vp.val_price,
                vah_30d=vp.vah_price,
                bb_inside_kc_4h=bb_in_kc_series[-1] if bb_in_kc_series else False,
                bb_bandwidth_4h=bbw_4h[-1] if bbw_4h else Decimal("0.2"),
                bb_inside_kc_4h_lookback=bb_in_kc_series[-16:],
                rvol_4h=snap_1h.relative_volume,
                oi_delta_7d=oi_7d,
                oi_delta_4h=oi_4h,
                oi_delta_1h=oi_1h,
                taker_buy_ratio_4h=taker_calc_4h,
                high_4h=c4h[-1].high,
                low_4h=c4h[-1].low,
                atr14_1h=snap_1h.atr14,
                funding_rate_8h=funding_rate,
                ret_7d=ret_7d,
                prior_bb_bandwidth_4h=bbw_4h[-2] if len(bbw_4h) >= 2 else Decimal("0.2"),
                pivot_resistance=max(c.high for c in c4h[-18:]),
                candle_4h_close_pos=(c4h[-1].close - c4h[-1].low) / max(c4h[-1].high - c4h[-1].low, Decimal("1e-8")),
                has_kinetic_ignition=False,
                pocket_pivot_1h=False,
                micro_expansion_1h=False,
                of_absorption_1h=False,
                taker_buy_ratio_1h=taker_buy_ratio_from_candles(c1h, hours=1),
                oi_delta_24h=oi_24h,
            )
            base_arch = classify_long_archetype(lf)
            base_pass, base_det = evaluate_long_gates(gi, base_arch)
            patch_arch, patch_pass, patch_det = eval_patched_archetype_and_gates(lf, gi)
            if base_pass and base_arch is not None:
                base_hits += 1
            if patch_pass and patch_arch is not None:
                patch_hits += 1
            failed_base = [k for k, v in base_det.items() if not v]
            failed_patch = [k for k, v in patch_det.items() if not v]
            print(
                f"  T-{h:2d}h ({last_ts.strftime('%m-%d %H:%M')}) | Price={close} (FwdToNow={fwd_ret:+6.2f}%) "
                f"| Base: {'PASS ('+base_arch.value+')' if (base_pass and base_arch) else 'FAIL '+str(failed_base)+' arch='+str(base_arch)} "
                f"| Patched: {'PASS ('+patch_arch.value+')' if (patch_pass and patch_arch) else 'FAIL '+str(failed_patch)+' arch='+str(patch_arch)}"
            )
            rows_279.append(
                {
                    "horizon_hours_ago": h,
                    "candle_closed_at_utc": last_ts.isoformat(),
                    "close": str(close),
                    "fwd_ret_pct": round(fwd_ret, 2),
                    "base_passed": bool(base_pass and base_arch is not None),
                    "base_archetype": base_arch.value if base_arch else None,
                    "base_failed_gates": failed_base,
                    "patched_passed": bool(patch_pass and patch_arch is not None),
                    "patched_archetype": patch_arch.value if patch_arch else None,
                    "patched_failed_gates": failed_patch,
                }
            )
        print(f"  >>> SUMMARY {sym}: Base Hits={base_hits}/12 | Patched Hits={patch_hits}/12")
        results["task_279_reproduction"][sym] = {
            "base_hits": base_hits,
            "patched_hits": patch_hits,
            "total_horizons": 12,
            "steps": rows_279,
        }

    print("\n=== REPRODUCING TASK-286 (Horizons: 36, 32, 28, 24, 20, 16, 12, 8, 4, 0) ===")
    for sym in SYMBOLS:
        sym_data = raw["symbols"][sym]
        q_info = raw["quotes_at_anchor"][sym]
        last_286 = Decimal(q_info["last_286"])
        funding_bps = float(Decimal(q_info["funding_rate"])) * 10000
        basis_bps = float(Decimal(q_info["basis_pct"])) * 10000
        c1h_all = [_deserialize_candle(d) for d in sym_data["candles_1h"]]
        c4h_all = [_deserialize_candle(d) for d in sym_data["candles_4h"]]
        oi_hist = sym_data["open_interest_hist_1h"]

        horizons_286 = [36, 32, 28, 24, 20, 16, 12, 8, 4, 0]
        cont_hits = []
        for h in horizons_286:
            c1h = c1h_all[:-h] if h > 0 else c1h_all
            last_ts = c1h[-1].closed_at
            c4h = [c for c in c4h_all if c.closed_at <= last_ts]
            snap_1h = snapshot(c1h)
            close = snap_1h.close
            fwd_ret = float((last_286 - close) / close * 100)
            closes_4h = [c.close for c in c4h]
            ema20_4h = ema(closes_4h, 20)[-1]
            ema50_4h = ema(closes_4h, 50)[-1]
            ema200_4h = ema(closes_4h, min(200, len(closes_4h)))[-1]
            rsi_4h = rsi(closes_4h, 14)[-1]
            ret_24h = _return_over(c1h, 24)
            last_72h = c1h[-72:]
            exc_72h = (max(c.high for c in last_72h) - min(c.low for c in last_72h)) / min(c.low for c in last_72h)
            base_win = c4h[-120:] if len(c4h) >= 120 else c4h
            high_30d = max(c.high for c in base_win)
            low_30d = min(c.low for c in base_win)
            vp = volume_profile(c4h[-180:] if len(c4h) >= 180 else c4h, bins=40)
            bb_u, bb_m, bb_l, bbw_4h = bollinger_bands(closes_4h, 20, Decimal("2.0"))
            kc_u, kc_m, kc_l = keltner_channels(c4h, 20, Decimal("1.5"))
            bb_in_kc = bool(
                bb_l[-1] and kc_l[-1] and bb_u[-1] and kc_u[-1] and bb_l[-1] >= kc_l[-1] and bb_u[-1] <= kc_u[-1]
            )
            _, _, vcr = volume_contraction_metrics(c1h, 7, 14)
            taker_4h = taker_buy_ratio_from_candles(c1h, hours=4)
            taker_1h = taker_buy_ratio_from_candles(c1h, hours=1)
            wicks_avg = (
                sum(float((c.high - max(c.open, c.close)) / max(c.high - c.low, Decimal("1e-8"))) for c in c4h[-4:])
                / 4.0
            )

            ts_ms = int(last_ts.timestamp() * 1000)
            oi_valid = [r for r in oi_hist if int(r["timestamp"]) <= ts_ms + 60000]
            oi_7d = oi_24h = oi_4h = oi_1h = None
            if len(oi_valid) >= 25:
                cur_oi = Decimal(str(oi_valid[-1]["sumOpenInterest"]))
                oi_1h = (cur_oi - Decimal(str(oi_valid[-2]["sumOpenInterest"]))) / Decimal(str(oi_valid[-2]["sumOpenInterest"]))
                oi_4h = (cur_oi - Decimal(str(oi_valid[-5]["sumOpenInterest"]))) / Decimal(str(oi_valid[-5]["sumOpenInterest"]))
                oi_24h = (cur_oi - Decimal(str(oi_valid[-25]["sumOpenInterest"]))) / Decimal(str(oi_valid[-25]["sumOpenInterest"]))
                idx_7d = max(0, len(oi_valid) - 169)
                oi_7d = (cur_oi - Decimal(str(oi_valid[idx_7d]["sumOpenInterest"]))) / Decimal(str(oi_valid[idx_7d]["sumOpenInterest"]))

            ok, sc, arch = institutional_continuous_eval(
                close,
                low_30d,
                high_30d,
                ema20_4h,
                ema50_4h,
                ema200_4h,
                vp.val_price,
                vp.poc_price,
                vp.vah_price,
                bbw_4h[-1],
                bb_in_kc,
                vcr,
                ret_24h,
                exc_72h,
                snap_1h.rsi14,
                rsi_4h,
                None,
                oi_7d,
                oi_24h,
                oi_4h,
                oi_1h,
                funding_bps,
                basis_bps,
                taker_4h,
                taker_1h,
                wicks_avg,
            )
            if ok:
                cont_hits.append((f"T-{h}h", str(close), f"{fwd_ret:+.1f}%", sc, arch))
        print(f"{sym:<10} | Continuous-Factor Hits={len(cont_hits)}/10 -> {cont_hits}")
        results["task_286_reproduction"][sym] = {
            "continuous_hits": len(cont_hits),
            "total_horizons": 10,
            "hits": cont_hits,
        }

    RESULTS_PATH.write_text(json.dumps(results, indent=2))
    return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fetch-and-freeze", action="store_true")
    args = parser.parse_args()
    if args.fetch_and_freeze or not RAW_INPUTS_PATH.exists():
        asyncio.run(fetch_and_freeze())
    run_offline_reproduction()


if __name__ == "__main__":
    main()
